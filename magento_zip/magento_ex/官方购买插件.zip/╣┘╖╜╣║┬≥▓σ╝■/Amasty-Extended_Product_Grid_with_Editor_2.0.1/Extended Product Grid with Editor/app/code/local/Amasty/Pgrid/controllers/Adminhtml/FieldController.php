<?php
/**
* @author Amasty Team
* @copyright Copyright (c) 2010-2011 Amasty (http://www.amasty.com)
* @package Amasty_Pgrid
*/
class Amasty_Pgrid_Adminhtml_FieldController extends Mage_Adminhtml_Controller_Action
{
    protected $_product = null;
    
    protected function _initProduct()
    {
        $productId      = $this->getRequest()->getPost('product_id');
        $field          = Mage::app()->getRequest()->getParam('field');
        if ('name' == $field)
        {
            // name field should always be saved with no store loaded
            $product        = Mage::getModel('catalog/product')->load($productId);
        } else 
        {
            $product        = Mage::getModel('catalog/product')->setStoreId($this->_getStore()->getId())->load($productId);
        }
        $this->_product = $product;
    }
    
    protected function _getStore()
    {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return Mage::app()->getStore($storeId);
    }
    
    protected function _getObject($field)
    {
        $obj = $this->_product;
                
        if (isset($field['obj']))
        {
            $obj = $this->_product->getData($field['obj']); // for example, stock_item
        }
        
        return $obj;
    }
    
    public function saveAction()
    {
        $this->_initProduct();
        if ($this->_product)
        {
            $result  = array();
            $field   = Mage::app()->getRequest()->getParam('field');
            $value   = Mage::app()->getRequest()->getParam('value');
            
            if ('custom_name' == $field)
            {
                $field = 'name';
            }
            
            $store   = $this->_getStore();
            
            $columnProps = Mage::helper('ampgrid')->getColumnsProperties(false, true);
            $obj         = $this->_product;
            
            if (isset($columnProps[$field]))
            {
                /* will save value. first need to check where to save (product itself, stock item, etc.)
                 * @see Amasty_Pgrid_Helper_Data
                 */
                
                $obj = $this->_getObject($columnProps[$field]);
                
                if (isset($columnProps[$field]['format']))
                {
                    switch ($columnProps[$field]['format'])
                    {
                        case 'numeric':
                            $value = str_replace(',', '.', $value);
                            $value = preg_replace('@[^0-9\.]@', '', $value);
                        break;
                    }
                }
                $obj->setData($columnProps[$field]['col'], $value);
                
                try
                {
                    if (method_exists($obj, 'validate'))
                    {
                        $obj->validate(); // this will validate necessary unique values
                    }
                } catch (Exception $e)
                {
                    $result = array(
                        'error'   => 1,
                        'message' => $e->getMessage(),
                    );
                }
                
                if (!isset($result['error']))
                {
                    $obj->save();
                    
                    $this->_initProduct();
                    $obj = $this->_getObject($columnProps[$field]);
                }
            }
            
            if (!isset($result['error']))
            {
                $outputValue  = $obj->getData($columnProps[$field]['col']);
                if (isset($columnProps[$field]))
                {
                    switch ($columnProps[$field]['type'])
                    {
                        case 'price':
                            $currencyCode = $store->getBaseCurrency()->getCode();
                            $outputValue  = sprintf("%f", $outputValue);
                            $outputValue  = Mage::app()->getLocale()->currency($currencyCode)->toCurrency($outputValue);
                        break;
                        case 'select':
                            if (isset($columnProps[$field]['options'][$outputValue]))
                            {
                                $outputValue = $columnProps[$field]['options'][$outputValue];
                            }
                        break;
                        case 'date':
                            $outputValue = Mage::getSingleton('core/locale')->date($outputValue, Zend_Date::ISO_8601, null, false)->toString(Mage::app()->getLocale()->getDateFormat(Mage_Core_Model_Locale::FORMAT_TYPE_MEDIUM));
                        break;
                    }
                }
                $result       = array('success' => 1, 'value' => $outputValue);
            }
            
        } else 
        {
            $result = array(
                'error'   => 1,
                'message' => $this->__('Unable to load product.'),
            );
        }
        
        $this->getResponse()->setBody(
            Mage::helper('core')->jsonEncode($result)
        );
    }
}