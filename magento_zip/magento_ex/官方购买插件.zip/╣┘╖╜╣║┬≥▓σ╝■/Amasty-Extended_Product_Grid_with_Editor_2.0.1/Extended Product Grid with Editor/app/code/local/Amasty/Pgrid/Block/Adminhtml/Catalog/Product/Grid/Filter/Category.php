<?php
/**
* @author Amasty Team
* @copyright Copyright (c) 2010-2011 Amasty (http://www.amasty.com)
* @package Amasty_Pgrid
*/
class Amasty_Pgrid_Block_Adminhtml_Catalog_Product_Grid_Filter_Category extends Mage_Adminhtml_Block_Widget_Grid_Column_Filter_Select
{
    public function getCondition()
    {
        $collection = Mage::registry('product_collection');
        if ($collection && $this->getValue())
        {
            $collection->addCategoryFilter(Mage::getModel('catalog/category')->load($this->getValue()));
        }
        return null;
    }
}