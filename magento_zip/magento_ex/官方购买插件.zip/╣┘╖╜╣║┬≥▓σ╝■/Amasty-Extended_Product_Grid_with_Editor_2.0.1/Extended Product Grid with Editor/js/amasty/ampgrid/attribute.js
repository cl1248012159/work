/**
* @author Amasty Team
* @copyright Copyright (c) 2010-2011 Amasty (http://www.amasty.com)
* @package Amasty_Pgrid
*/

eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('g 4=f e.h();4.i={l:2(0){5.0=0},d:2(){3=j.m($(\'c\').8,{7:1,9:1,b:1,a:"k",E:"z-n",0:5.0,x:A,B:D,C:w,v:q,p:6.o,r:6.s,u:\'3\',})},t:2(){3.y()}};',41,41,'title|true|function|attributeDialog|amPattribute|this|Element|draggable|innerHTML|resizable|className|closable|pAttribute_block|showConfig|Class|new|var|create|prototype|Dialog|magento|initialize|info|window|hide|hideEffect|false|showEffect|show|closeConfig|id|recenterAuto|1000|width|close|popup|700|height|zIndex|600|windowClassName'.split('|'),0,{}))
