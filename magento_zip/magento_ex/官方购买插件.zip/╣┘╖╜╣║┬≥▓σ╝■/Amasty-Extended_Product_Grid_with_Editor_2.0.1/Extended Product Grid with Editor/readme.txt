Thank you for buying the extension. If you will need support, please send an email to amastysupport@gmail.com

Installation
1) Create full backup of your site (both files and database)

2) !!!VERY IMPORTANT!!! go to admin panel -> System -> Tools -> Compilation and make sure that Compiler Status is disabled. If it's not, please change it to disabled. If you plan to use the compilation after installing the extension, please click 'Run Compilation Process' button after you complete the extension installation.

3) copy files to the magento root folder

4) log in as admin and refresh all caches (System > Cache Management)



Installation is complete.

Thank you for the purchase.


------- If you will have any issues with the extension, please disable the extension the following way: --------

1. Open file app/etc/modules/Amasty_Pgrid.xml, find this line of code:

<active>true</active>

and change it to:

<active>false</active>

2. log in as admin and refresh all caches (System > Cache Management)



After that please send an email to amastysupport@gmail.com with description of the issue(s) and access information.
