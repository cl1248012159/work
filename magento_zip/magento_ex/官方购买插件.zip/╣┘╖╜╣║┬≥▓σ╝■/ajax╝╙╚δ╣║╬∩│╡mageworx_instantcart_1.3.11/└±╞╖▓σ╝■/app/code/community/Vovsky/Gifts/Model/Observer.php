<?php
class Vovsky_Gifts_Model_Observer
{
    public function __construct()
    {
    }

    public function giftincart()
    {
        $items = Mage::getSingleton('checkout/cart')->getQuote()->getAllItems();
        foreach($items as $item){
        	if ($item->getOriginalCustomPrice()==0 && (Mage::getModel('catalog/product')->load($item['product_id'])->getGiftvalue()>0))
        		return(true);
        }
        
        return(false);
    } 

    
    public function hookToControllerActionPostDispatch($observer)
    {

        if($observer->getEvent()->getControllerAction()->getFullActionName() == 'checkout_cart_delete' || $observer->getEvent()->getControllerAction()->getFullActionName() == 'checkout_cart_updatePost' ){
	        $items = Mage::getSingleton('checkout/cart')->getQuote()->getAllItems();
	        foreach($items as $item){
	        	if ($item->getOriginalCustomPrice()==0 && Mage::getModel('catalog/product')->load($item['product_id'])->getGiftvalue()> Mage::getSingleton('checkout/cart')->getQuote()->getGrandTotal()){
	        		Mage::getSingleton('checkout/cart')->removeItem($item->getId())->save();	
	        	}	
	        }
        }
    }
    

    
    public function controlQty($observer)
    {
		$items = Mage::getSingleton('checkout/cart')->getQuote()->getAllItems();
        foreach($items as $item){
        	if ($item->getPrice()==0 && Mage::getModel('catalog/product')->load($item['product_id'])->getGiftvalue()>Mage::getSingleton('checkout/cart')->getQuote()->getGrandTotal()){
        		Mage::getSingleton('checkout/cart')->removeItem($item->getId())->save();
        			
        	}	
        }

		$event = $observer->getEvent();
		$product = $event->getProduct();   
		$cart = $event->getCart();
		$data = $event->getInfo();			
		foreach ($data as $itemId => $itemInfo) {
            $item = $cart->getQuote()->getItemById($itemId);
            if (!$item) {
                continue;
            }
           if (Mage::getModel('catalog/product')->load($item['product_id'])->getGiftvalue()){           
	     		if ($item->getOriginalCustomPrice()!=null){
		     		if ($item->getOriginalCustomPrice()==0.00){
		     			$item->setQty(1);
		     			$item->save();
		     			}
	     		}	
			}
		}
	}
            

    
    public function make_gift($observer)
    {
	$items = Mage::getModel('checkout/cart')->getQuote()->getAllItems();     
	$event = $observer->getEvent();
	$product = $event->getProduct();   
	$quote_item = $event->getQuoteItem();
   	
   	foreach($items as $item){
   		if (Mage::getModel('catalog/product')->load($item['product_id'])->getGiftvalue() && ($item->getOriginalCustomPrice())){
	   		if ($item->getOriginalCustomPrice()==0.00){
		   		if ($item['sku']==$quote_item['sku']){
		   			$item->setQty(1);
		   			$item->save();
		   		}
			}	
   		}
   	} 

     if (Mage::app()->getRequest()->getParam('g')){
     	
     	if (Mage::getModel('catalog/product')->load($quote_item['product_id'])->getGiftvalue()){
	     	if (Mage::getModel('catalog/product')->load($quote_item['product_id'])->getGiftvalue()<Mage::getModel('checkout/session')->getQuote()->getGrandTotal()){
	     		$quote_item->setOriginalCustomPrice(0.00); 
	     		$quote_item->calcRowTotal(); 
				$quote_item->save();
			}
		}
	}
	 
    return $this;
    }
}