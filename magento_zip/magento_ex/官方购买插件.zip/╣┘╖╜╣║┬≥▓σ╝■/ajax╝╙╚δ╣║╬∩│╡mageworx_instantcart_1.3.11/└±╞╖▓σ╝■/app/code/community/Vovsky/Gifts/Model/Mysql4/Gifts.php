<?php

class Vovsky_Gifts_Model_Mysql4_Gifts extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the gifts_id refers to the key field in your database table.
        $this->_init('gifts/gifts', 'gifts_id');
    }
}