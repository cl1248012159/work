<?php
$installer = $this;
$attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')
                        ->setCodeFilter('giftvalue')
                        ->getFirstItem();
                        
if (($attributeInfo) && ($attributeInfo['backend_type']!='decimal')){                        
	$res = Mage::getSingleton('core/resource');
	$write = Mage::getSingleton('core/resource')->getConnection('core_write');
	$result=$write->query("SELECT *
	FROM ".$res->getTableName('catalog_product_entity_int')."
	WHERE
	attribute_id = ".$attributeInfo['attribute_id']);
	
	while ($row = $result->fetch() ) {
		$write->query("DELETE FROM ".$res->getTableName('catalog_product_entity_decimal')." WHERE `attribute_id`='".$row['attribute_id']."' AND `entity_id`='".$row['entity_id']."'");
		$write->query("INSERT INTO ".$res->getTableName('catalog_product_entity_decimal')." (
		`value_id` ,
		`entity_type_id` ,
		`attribute_id` ,
		`store_id` ,
		`entity_id` ,
		`value`
		)
		VALUES (
		NULL , '".$row['entity_type_id']."', '".$row['attribute_id']."', '".$row['store_id']."', '".$row['entity_id']."', '".$row['value']."'
		) ");
		//die();
		$write->query("DELETE FROM ".$res->getTableName('catalog_product_entity_int')." WHERE `value_id`='".$row['value_id']."'");
		
	}
}



//die();
$installer->installEntities();
