<?php
class Vovsky_Gifts_Block_Gifts extends Mage_Core_Block_Template
{
 	public function getGifts()
    {
        $items = Mage::getModel('checkout/cart')->getQuote()->getAllItems();
        $exids = array();
        
        foreach($items as $item){
	   		if (Mage::getModel('catalog/product')->load($item['product_id'])->getGiftvalue())
	   			$exids[] = 	$item['sku'];  		
   		}
   		$storeId = Mage::app()->getStore()->getId();
        $collection = Mage::getModel('catalog/product')->getCollection()->addStoreFilter($storeId);
        $collection->addAttributeToSelect('*');
        $collection->addFieldToFilter('giftvalue',array('lteq'=>Mage::getModel('checkout/cart')->getQuote()->getGrandTotal()));
        $collection->addFieldToFilter('giftvalue',array('gt'=>0));
        if (count($exids)>0){
        	$collection->addFieldToFilter('sku',array('nin'=>$exids));}
        if ($collection->count()){
	        return($collection);
	        }
	    else
	    	return(false);
    }
    public function giftincart()
    {
        $items = Mage::getSingleton('checkout/cart')->getQuote()->getAllItems();
        foreach($items as $item){
        	if ($item->getPrice()==0 && Mage::getModel('catalog/product')->load($item['product_id'])->getGiftvalue()){	        	
	        	return(true);
        	}
        }
        return(false);
    } 
}