<?php
/**
 * @copyright  Copyright (c) 2010 Amasty (http://www.amasty.com)
 */  
class Amasty_Base_Helper_Data extends Mage_Core_Helper_Abstract
{
}