<?php

class Amasty_Shopby_Block_Catalog_Layer_Filter_Attribute extends Mage_Catalog_Block_Layer_Filter_Attribute
{
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('amshopby/attribute.phtml'); 
    }
    
    public function getItemsAsArray()
    {
        $items = array(); 
        foreach (parent::getItems() as $itemObject){
            $item = array();
            $item['url']   = $this->htmlEscape($itemObject->getUrl());
            
            if ($this->getSingleChoice()){ /** sinse @version 1.3.0 */
                $query = array(
                    $this->getRequestValue() => $itemObject->getOptionId(),
                    Mage::getBlockSingleton('page/html_pager')->getPageVarName() => null 
                ); 
                $item['url'] = Mage::helper('amshopby/url')->getFullUrl($query);            
            }
            $item['label'] = $itemObject->getLabel();

            $item['count'] = '';
            if (!$this->getHideCounts())
                $item['count']  = ' (' . $itemObject->getCount() . ')';
            
            $item['image'] = '';
            if ($itemObject->getImage()){
                $item['image'] = Mage::getBaseUrl('media') . 'amshopby/' . $itemObject->getImage();
            }

            $item['css'] = 'amshopby-attr';
            if ($itemObject->getIsSelected()){
                $item['css'] .= '-selected';
                if (3 == $this->getDisplayType()) //dropdown
                    $item['css'] = 'selected';
            }
            
            $items[] = $item;
        }
        
        $sortBy = $this->getSortBy();
        $functions = array(1 => '_sortByName', 2 => '_sortByCounts');
        if (isset($functions[$sortBy])){
            usort($items, array($this, $functions[$sortBy]));
        } 
        
        // add less/more
        $max = $this->getMaxOptions();
        $i   = 0;
        foreach ($items as $k=>$item){
            $style = '';
            if ($max && (++$i > $max)){
                $style = 'style="display:none" class="amshopby-attr-' . $this->getRequestValue() . '"'; 
            }        
            $items[$k]['style'] = $style;
        }
        $this->setShowLessMore($max && ($i > $max));
        
        return $items;
    }
    
    public function _sortByName($a, $b)
    {
        return strcmp($a['label'], $b['label']);
    }
    
    public function _sortByCounts($a, $b)
    {
        return ($a['count'] < $b['count']);
    }
    
    public function getRequestValue()
    {
        return $this->_filter->getAttributeModel()->getAttributeCode();
    }
    
     public function getItemsCount()
     {
        $cnt     = parent::getItemsCount();
        $showAll = !Mage::getStoreConfig('amshopby/general/hide_one_value'); 
        return ($cnt > 1 || $showAll) ? $cnt : 0;
     }
}