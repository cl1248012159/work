<?php
/**
* @copyright Amasty.
*/ 
class Amasty_Shopby_Block_Top extends Mage_Core_Block_Template
{
    private $options = array();
    
    private function trim($str)
    {
        $str = strip_tags($str);  
        $str = str_replace('"', '', $str); 
        return trim($str, " -");
    }
    
    protected function _prepareLayout()
    {
        //fix wrong canonical URL for the root category for 1.4+
        $hasCanonical = !Mage::helper('amshopby')->isVersionLessThan(1, 4);
        $isShopby     = in_array(Mage::app()->getRequest()->getModuleName(), array('shopby', 'amshopby'));
        if ($hasCanonical && $isShopby){
            $url = Mage::getSingleton('catalog/layer')->getCurrentCategory()->getUrl();
            
            $head = $this->getLayout()->getBlock('head');
            $head->removeItem('link_rel', $url);
            $head->addLinkRel('canonical', Mage::getBaseUrl() . 'shopby');
        }   
        //end fix     
        
        $filters = Mage::getResourceModel('amshopby/filter_collection')
                ->addTitles()
                ->setOrder('position');
                
        $hash = array();
        foreach ($filters as $f){
            $vals = Mage::helper('amshopby')->getRequestValues($f->getAttributeCode());
            if ($vals){
                foreach($vals as $v)
                    $hash[$v] = $f->getShowOnList();            
            }
        }
        
        if (!$hash)
            return parent::_prepareLayout();    
        
        $options = Mage::getResourceModel('amshopby/value_collection')
            ->addFieldToFilter('option_id', array('in' => array_keys($hash)))
            ->load();
          
        $cnt = $options->count();
        if (!$cnt)
            return parent::_prepareLayout(); 
            
        //some of the options value have wrong value; 
        if ($cnt && $cnt < count($hash)){
            return parent::_prepareLayout(); 
            // or make 404 ?
        }            
              
        // sort options by attribute ids and add "show_on_list" property
        foreach ($options as $opt){ 
            $id = $opt->getOptionId();
            
            $opt->setShowOnList($hash[$id]);
            $hash[$id] = clone $opt;         
        }
        
        // unset "fake"  options (not object)
        foreach ($hash as $id => $opt){
            if (!is_object($opt))
                unset($hash[$id]);     
        }    
        if (!$hash)
            return parent::_prepareLayout();        


        $head = $this->getLayout()->getBlock('head');
        if ($head){
            $title = $head->getTitle();
            $descr = $head->getDescription();
          
            $titleSeparator = Mage::getStoreConfig('amshopby/general/title_separator');
            $descrSeparator = Mage::getStoreConfig('amshopby/general/descr_separator');
            foreach ($hash as $opt){
                if ($opt->getMetaTitle())
                    $title .= $titleSeparator . $opt->getMetaTitle();
                    
                if ($opt->getMetaDescr())
                    $descr .= $descrSeparator . $opt->getMetaDescr();
            }
   
            $head->setTitle($this->trim($title)); 
            $head->setDescription($this->trim($descr)); 
        }
        $this->options = $hash;
              
        return parent::_prepareLayout();
    }
    
    public function getOptions()
    {
        $res = array();
        foreach ($this->options as $opt){
            if (!$opt->getShowOnList())
                continue;
                
            $item = array();
            $item['title'] = $this->htmlEscape($opt->getTitle());
            $item['descr'] = $opt->getDescr();
            $item['cms_block'] = '';
            
            $blockName = $opt->getCmsBlock();
            if ($blockName) {
                $item['cms_block'] = $this->getLayout()
                    ->createBlock('cms/block')
                    ->setBlockId($blockName)
                    ->toHtml();
            }
            
            $item['image'] = '';
            if ($opt->getImgBig())
                $item['image'] = Mage::getBaseUrl('media') . '/amshopby/' . $opt->getImgBig();
            $res[] = $item;
        }
        return $res;
    }

}