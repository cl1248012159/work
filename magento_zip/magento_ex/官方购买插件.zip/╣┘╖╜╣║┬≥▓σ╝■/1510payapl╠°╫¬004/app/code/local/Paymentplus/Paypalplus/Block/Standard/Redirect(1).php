<?php

class Paymentplus_Paypalplus_Block_Standard_Redirect extends Mage_Core_Block_Abstract {
    
    protected function _toHtml() {
        
        $url = '';
        $post = $_POST;
        $fields = array();
        $standard = Mage::getModel('paypal/standard');
        $paypalplus = Mage::getModel('paypalplus/status');
        header('P3P:CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT"');
        
        if (isset($post['payredirect']) && 1 == $post['payredirect']) {
            unset($post['payredirect']);
            Mage::log('jump ready');
            $store_id = $paypalplus->getJumpSiteId($post['jumpsite']);
            unset($post['jumpsite']);
            Mage::log($store_id);
            if ($store_id !== false) {
                $post['return'] = $post['return']. '/id/'. $store_id;
                $post['cancel_return'] = $post['cancel_return']. '/id/'. $store_id;
                $post['notify_url']  = $post['notify_url']. '/id/'. $store_id;
            }
            $post['item_name'] =  Mage::app()->getGroup()->getName();
            $post['business'] = $paypalplus->getBusinessAccount();
            $fields = $post;
        } else {
            $fields = $standard->getStandardCheckoutFormFields();
        }

        if ($paypalplus->getPayRedirect()) {
            
            $payredirectsite = $paypalplus->getPayRedirectSite();
            //$store_id = Mage::app()->getStore(null)->getId();
            $url = $payredirectsite . 'index.php/paypal/standard/redirect';
            
            $fields['jumpsite'] = Mage::app()->getStore(null)->getUrl();
            $fields['payredirect'] = 1;
            $fields['return'] = $payredirectsite. 'paypal/standard/success';
            $fields['cancel_return'] = $payredirectsite. 'paypal/standard/cancel';
            $fields['notify_url']  = $payredirectsite. 'paypal/ipn/index';
            $fields['address_override'] = 0;
            
        } else {
            $url = $standard->getConfig()->getPaypalUrl();
        }
        
        $form = new Varien_Data_Form();
        $form->setAction($url)
            ->setId('paypal_standard_checkout')
            ->setName('paypal_standard_checkout')
            ->setMethod('POST')
            ->setUseContainer(true);
        foreach ( $fields as $field=>$value) {
            $form->addField($field, 'hidden', array('name'=>$field, 'value'=>$value));
        }
        $html = '<html><body>';
        $html.= $this->__('You will be redirected to the PayPal website in a few seconds.');
        $html.= $form->toHtml();
        if ($paypalplus->getPayRedirect()) {
            $html.= '<iframe name="innerform" frameborder="0" width="0" height="0"></iframe>';
            $html.= '<script type="text/javascript">var form = document.getElementById("paypal_standard_checkout");form.setAttribute("target","innerform"); document.getElementById("paypal_standard_checkout").submit();</script>';
        } else {
            $html.= '<script type="text/javascript">var form = document.getElementById("paypal_standard_checkout");form.setAttribute("target","_top");document.getElementById("paypal_standard_checkout").submit();</script>';
        }
        $html.= '</body></html>';

        return $html;
    }
}