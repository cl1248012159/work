<?php

class Paymentplus_Paypalplus_Model_Ipn extends Mage_Paypal_Model_Ipn {
    
    private function _post($_request, $url, Zend_Http_Client_Adapter_Interface $httpAdapter) {
        
        $sReq = '';
        foreach ($_request as $k => $v) {
            $sReq .= '&'.$k.'='.urlencode(stripslashes($v));
        }
        Mage::log($sReq);
        $sReq = substr($sReq, 1);
        Mage::log($sReq);

        $httpAdapter->write(Zend_Http_Client::POST, $url, '1.1', array(), $sReq);
        try {
            $response = $httpAdapter->read();
            Mage::log('$response:');
            Mage::log($response);
        } catch (Exception $e) {
            Mage::log('Ipn send error');
            Mage::log(array('error' => $e->getMessage(), 'code' => $e->getCode()));
        }
    }
    
    private function _getStoreId() {
        $store_id = null;
        foreach(Mage::app()->getRequest()->getParams() as $key=>$id) {
            Mage::log("{$key}=>{$id}");
            if($key == 'id') {
                return (int)$id;
            } else {
                return false;
            }
        }
    }
        
    private function _chkRedirect($url) {
        $sid = '';
        $store_id = $this->_getStoreId();

        $paypalplus = Mage::getModel('paypalplus/status');
        
        if ($store_id !== false) {
            $jumpurl =  $paypalplus->getJumpSiteUrl($store_id);
            if ($jumpurl !== false) {
                if (isset($_GET['SID'])) {
                    $sid = '?SID='.$_GET['SID'];
                }
                $url = $jumpurl. $url . $sid;
                
                if ($_POST) {
                    $httpAdapter = new Varien_Http_Adapter_Curl();
                    $this->_post($_POST, $url, $httpAdapter);
                    Mage::log('post date');
                    die();
                }
        
                header("Location: {$url}");
                die();
            } else {
                Mage::log("jump site id: {$store_id} error!");
            }
        }
    }
    
    public function processIpnRequest(array $request, Zend_Http_Client_Adapter_Interface $httpAdapter = null) {
        $this->_chkRedirect('paypal/ipn/');
        return parent::processIpnRequest($request, $httpAdapter);
    }
}