<?php

class Paymentplus_Paypalplus_Model_Status extends Mage_Paypal_Model_Standard {

    public function getPayRedirect() {
        $payredirecton = Mage::getStoreConfig('paymentplus/paypal_plus/payredirecton');
        
        if ($payredirecton) {
            $site = strtolower(Mage::app()->getStore(null)->getUrl());
            $payredirectsite = strtolower(Mage::getStoreConfig('paymentplus/paypal_plus/payredirectsite'));
            return strpos($site, $payredirectsite) === false;
        } else {
            return false;
        }
    }
    
    public function getPayRedirectSite() {
        return Mage::getStoreConfig('paymentplus/paypal_plus/payredirectsite');
    }
    
    public function getBusinessAccount() {
        $api = Mage::getModel('paypal/api_standard')->setConfigObject($this->getConfig());
        return $api->getBusinessAccount();
    }
    
    public function getPayJumpSites() {
        return Mage::getStoreConfig('paymentplus/paypal_plus/payjumpsite');
    }
    
    public function getJumpSiteUrl($id) {

        $sites = explode(';', $this->getPayJumpSites());
        if(isset($sites[$id]) && $sites[$id]) {
            return $sites[$id];
        } else {
            return false;
        }
    }
    
    public function getJumpSiteId($url) {
        $sites = explode(';', $this->getPayJumpSites());

        foreach($sites as $id =>$site) {
            if (strpos($url, $site) !== false) {
                return $id;
            }
        }
        return false;
    }
}
