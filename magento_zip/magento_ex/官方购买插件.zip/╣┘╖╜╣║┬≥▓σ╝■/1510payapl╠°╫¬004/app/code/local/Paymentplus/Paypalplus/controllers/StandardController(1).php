<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category   Mage
 * @package    Mage_Paypal
 * @copyright  Copyright (c) 2008 Irubin Consulting Inc. DBA Varien (http://www.varien.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * Paypal Standard Checkout Controller
 *
 * @category   Mage
 * @package    Mage_Paypal
 * @author      Magento Core Team <core@magentocommerce.com>
 */
 
require_once 'Mage/Paypal/controllers/StandardController.php';

class Paymentplus_Paypalplus_StandardController extends Mage_Paypal_StandardController {

    private function _getStoreId() {
        $store_id = null;
        foreach($this->getRequest()->getParams() as $key=>$id) {
            Mage::log("{$key}=>{$id}");
            if($key == 'id') {
                return (int)$id;
            } else {
                return false;
            }
        }
        return false;
    }
    
    private function _chkRedirect($url) {
        
        $sid = '';
        $store_id = $this->_getStoreId();
        $paypalplus = Mage::getModel('paypalplus/status');
        
        if ($store_id !== false) {
            $jumpurl =  $paypalplus->getJumpSiteUrl($store_id);
            if ($jumpurl !== false) {
                if (isset($_GET['SID'])) {
                    $sid = '?SID='.$_GET['SID'];
                }
                $url = $jumpurl. $url . $sid;
                
                if ($_POST) {
                    $form = new Varien_Data_Form();
                    $form->setAction($url)
                        ->setId('paypal_standard_return')
                        ->setName('paypal_standard_return')
                        ->setMethod('POST')
                        ->setUseContainer(true);
                    foreach ($_POST as $field=>$value) {
                        $form->addField($field, 'hidden', array('name'=>$field, 'value'=>$value));
                    }
                    $html = '<html><body>';
                    $html.= $form->toHtml();
                    $html.= '<script type="text/javascript">document.getElementById("paypal_standard_return").submit();</script>';
                    $html.= '</body></html>';
                    echo $html;
                    die();
                }
                Mage::log('go to :'.$url);
                header("Location: {$url}");
                die();
            } else {
                Mage::log("jump store_id: {$store_id} error!");
            }
        }
    }
    
    public function cancelAction() {
        
        $this->_chkRedirect('paypal/standard/cancel/');
        $session = Mage::getSingleton('checkout/session');
        $session->setQuoteId($session->getPaypalStandardQuoteId(true));
        if ($session->getLastRealOrderId()) {
            $order = Mage::getModel('sales/order')->loadByIncrementId($session->getLastRealOrderId());
            if ($order->getId()) {
                $order->cancel()->save();
            }
        }
        $this->_redirect('checkout/cart');
    }
    
    public function  successAction() {
        
         $this->_chkRedirect('paypal/standard/success/');
        $session = Mage::getSingleton('checkout/session');
        $session->setQuoteId($session->getPaypalStandardQuoteId(true));
        Mage::getSingleton('checkout/session')->getQuote()->setIsActive(false)->save();
        $this->_redirect('checkout/onepage/success', array('_secure'=>true));
    }
    
}
