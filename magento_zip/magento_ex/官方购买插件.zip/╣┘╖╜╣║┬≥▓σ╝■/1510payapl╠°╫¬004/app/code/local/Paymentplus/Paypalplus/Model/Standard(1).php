<?php

class Paymentplus_Paypalplus_Model_Standard extends Mage_Paypal_Model_Standard {}
